<?php

namespace app\models;
use ishop\base\Model;
class AppModel extends Model
{
	
}