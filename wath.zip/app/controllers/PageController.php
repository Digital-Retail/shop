<?php

namespace app\controllers;


class PageController extends AppController
{
	
}